<?php



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarot Course Online</title>
    <link rel="stylesheet" href="Tarot_main - Copy.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <header>
    <nav>
      <img class="logo" src="logo.jpg">
      <ul>
        <li class="menu"><button><a href="#home">Home</a></button></li>
        <li class="menu"><button><a href="#aboutus">About Us</a></button></li>
        <li class="menu"><button><a href="#lectures03">Lectures</a></button></li>
        <div class="dropdown">
           <button class="dropbtn">Course</button>
        <div class="dropdown-content">
          <a href="hide_sy.html">Our Syllabus</a>
          <a href="demo_certfy.html">Demo Certificate</a>
        </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Gallery </button>
          <div class="dropdown-content">
            <a href="#achi">Our achivement</a>
            <a href="#story">Success stories</a>
            
          </div>
        </div>
        
        <li class="menu"><button><a href="#footer">Contact</a></button></li>

        <li class="menu" class="regi"><button><a href="form.html">Register</a></button></li>

        <div class="dropdown">
          <button class="dropbtn">Get in touch </button>
          <div class="dropdown-content">
            <a href="https://wa.me/+918446123415"> Miss. Jadhav</a>
            <a href="https://wa.me/+918010210685">Miss. Kadam</a>
            <a href="https://wa.me/+9188113900738">Miss. Pawar</a>
          </div>
        </div>
        
        </nav>
  </header>
  
    <img class="image1" src="timg13.jpg">
    <main>
        
        <div id="home">
          <h1>To turn your Tarot Career into a whopping <br>6-Figure business </h1>
          <p>Learn the ancient art of tarot reading with our online course...!!!</p>
        </div>
    </main>
    <div class="course-container">
  <h2>We Ultimate Tarot Secret Course where you'll learn...</h2>
  <ul>
    <li>✅My<b> Secret ICP Framework</b> to make you a <br>confident Tarot Reader </li>
    <li>✅Develop to make strong intuitive power</li>
    <li>✅Memorize all 78 cards</li>
    <li>✅Make Clean and energize your  all cards</li>
    <li>✅Give <b>accurate predictions</b> for your clients</li>
    <li>✅To Build a your <b>successful tarot career</b></li>
  </ul>

  <div class="expanded-content">
    <h2>Tarot is more than just memorizing the cards</h2>
    <hr><hr>
    <div class="hide">
     <p>🔹It's about developing intuition,tapping into your inner wisdom and uncover meaning behind
     various situations and questions which many beginner Tarot Readers miss implementing in their readings</p>
     <p>🔹If you are Someone Who wants to build a successful career in Tarot Reading<br>
       or If you are already on a journey learn to improve and achive a higher level</p>
     <p>🔹You will experience a dramatic change in your readings and your way to think for Tarot reading success.</p>
     <p>🔹We will provide extra BONUSES litterly no one tell you to grow up.
         <hr>
         <h2>Hurry up!!! To join Our excluse webinar.</h2>
    </p>
    </div>
  </div>
  <br>
</div><br>
<hr><br>
<!---About us-->
  <div class="container">
      <div id="aboutus"class="image">
        <img src="about2.jpeg">
      </div>
     <div class="text">
        <h2 class="about">Co-founder of the Tarot course</h2>
        <h4 class="about1">Welcome to Tarot Course, where we believe in empowering individuals to unlock
            their full potential through the ancient art of tarot reading. Our mission is to
             provide a comprehensive and interactive online course that teaches you everything you 
             need to know to become a confident and accurate tarot reader.</h4>
     </div>
   </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
  <div class="chart-container">
  
    <!-- Pie Chart Container -->
    <div class="chart">
      <canvas id="myPieChart"></canvas>
    </div>
  
    <!-- Bar Chart Container -->
    <div class="chart">
      <canvas id="myBarChart"></canvas>
    </div>
  
  </div>
  
  <script>
  // Pie Chart
  const pieXValues = ["Our Popularity", "Growth of last 2 year", "Trust of peoples", "Successful students", "Current status"];
  const pieYValues = [55, 30, 41, 40, 21];
  const pieBarColors = ["red", "green", "blue","orange","brown"];
  
  new Chart("myPieChart", {
  type: "pie",
  data: {
  labels: pieXValues,
  datasets: [{
  backgroundColor: pieBarColors,
  data: pieYValues
  }]
  },
  options: {
  title: {
  display: true,
  text: "Here is the Percentage of our Each achievement...!!"
  }
  }
  });
  
  // Bar Chart
  const barXValues = ["India", "Europe", "Californiya", "USA", "New York", "Other"];
  const barYValues = [40, 32, 30, 28, 36,25];
  const barColors = ["red","green","blue","orange","brown"];
  
  new Chart("myBarChart", {
  type: "bar",
  data: {
  labels: barXValues,
  datasets:[{
  backgroundColor: barColors,
  data : barYValues
  }]
  },
  options:{
  legend:{display:false},
  title:{
  display:true,
  text:"Percentage of Students connects us from overall the world..!!!"
  }
  }
  });
  </script>
  <br><hr>
  <!----lectures1----->
  <video id="video1" width="315" controls>
    <source src="Samruddhi.mp4" type="video/mp4">
    <source src="Samruddhi.ogg" type="video/ogg">
    Your browser does not support HTML video.
  </video>
  <div>
    <img  id="lectures03" src="samu.jpeg" class="profile-picture">
  </div>
  <div class="text">
    <h2>Jadhav Samruddhi</h2>
    <p class="p1">My Tarot School,In the New York City, Here I achived not only CERTIFICATE
       but fullfilments of my all the desires and wishesh. They provide certifications and
       coursesin tarot reading. I has experiance in this field more than 5years and I tought more than 40k students yet.</p>
  </div>
  <br><hr>
<!--lecture 2---->
<video id="video1" width="320" controls>
  <source src="sperituality.mp4" type="video/mp4">
  <source src="sperituality.ogg" type="video/ogg">
  Your browser does not support HTML video.
</video>
<div>
  <img src="saloni.jpeg" class="profile-picture">
</div>
<div class="text">
  <h2>Kadam Saloni</h2>
  <p class="p1">The Chopra Center, I learnt courses and certifications 
  in meditation, mindfulness, and holistic well-being. After accomplishing it I got many rewards
  as the Award-Winning Meditator,Recognized Mindfulness Practitioner,Meditation Champion in my last 34 years.</p>
</div>
<br><hr>
<!---lecture 3---->
<video id="video1" width="320" controls>
  <source src="sperituality.mp4" type="video/mp4">
  <source src="sperituality.ogg" type="video/ogg">
  Your browser does not support HTML video.
</video>
<div>
  <img src="pooja.jpeg" class="profile-picture">
</div>
<div class="text">
  <h2>Pawar Pooja</h2>
  <p class="p1">The IAS provides spiritual sciences, and energy healing. & The my Crystal Academy I learnt
     crystal  healing and related subjects.I achived certifications upon  completion of their programs.
     I has tought more than 20k students with 3 years of experiance.</p>
</div>
<br><hr><br>
<!---syllabus-->
<!---achivement----->
<div>
  <p3 class="us">⭐Best achivement for us⭐</p3>
</div>
<div id="achi" class="achievement-gallery">
  <img src="achive1.jpeg" alt="Achievement 1" data-featherlight="achive1.jpg">
  <img src="achive2.jpeg" alt="Achievement 2" data-featherlight="achive2.jpg">
  <img src="achive3.jpeg" alt="Achievement 3" data-featherlight="achive3.jpg">
  <img src="medal.jpeg" alt="Achievement 4" data-featherlight="medal2.jpg">
  <img src="medal2.jpeg" alt="Achievement 5" data-featherlight="medal2.jpg">
  <img src="timg11.jpeg" alt="Achievement 6" data-featherlight="timg11.jpgg">
  <img src="timg12.jpeg" alt="Achievement 7" data-featherlight="timg12.jpg">
</div>
<br><hr><br>
<!--Feedbacks -->
<section class="testimonials">
  <p5 id="story" class="feed" class="animate__animated animate__fadeIn">🤩Success Stories...!!!🤩</p5>
  <div class="testimonials-container">
    <div class="testimonial">
      <img src="std2.jpeg" class="animate__animated animate__pulse">
        <img class="certfy" src="Shweta.jpg" class="animate__animated animate__pulse">
      <p class="fadeIn">"❤️I never thought I'd be able to understand 
        Tarot readings, 🤗but this course made it so easy! I'm so grateful for the knowledge and 
        confidence I've gained."Only because of this plat form and their mentors I' earning 6-figures
         monthly some time more than it😍 - Shweta Suryawanshi</p>
    </div>
    <div class="testimonial">
       <img src="std1.jpeg" class="animate__animated animate__pulse">
       <img class="certfy" src="babu.jpg" class="animate__animated animate__pulse">
      <p class="fadeIn">"⭐I was skeptical at first, but this course
        exceeded all my expectations. 🤩The lessons were informative and engaging, and I can't wait 
        to continue learning!" 😇This platform made me an successful and lots of positive changes  within me.🤞 - Baburao Jadhav</p>
    </div>
    <div class="testimonial">
      
       <img src="std3.jpeg" class="animate__animated animate__pulse">
       <img class="certfy"  src="Pranali.jpg" class="animate__animated animate__pulse">
      <p class="fadeIn">🤗"I've tried other Tarot courses before,
         but this one is the best. 👍The instructor is knowledgeable and supportive, and the 
         materials are top-notch.💕"All the tranformations happened within me htlps to flow wards my goal and success.💯 - Pranali Pawar</p>
    </div>
  </div>
</section>



  <!--footer---->  
  <footer>
    <div id="footer" class="footer-container">
        <div class="footer-content">
            <h3>Tarot Reading Online Course</h3>
            <p>Unlock the secrets to a successful and peaceful life...</p>
            <button class="join-btn"><a href="form.html">Join us</a></button>
        </div>
        <p class="con">
          GET IN TOUCH👇<br>
           <i class="fa fa-volume-control-phone" aria-hidden="true"><a href="https://wa.me/+918446123415">8446123415</a></i><br>
           <a href="https://wa.me/+918010210685" class="fa fa-volume-control-phone" aria-hidden="true">8010210685</a><br>
            <a href="https://wa.me/+918113900738" class="fa fa-volume-control-phone" aria-hidden="true">8113900738</a><br>
           <i style="font-size:24px" class="fa">&#xf0e0; tarotcoursessp@gmail.com</i>
        <p>
        <button class="go-top-btn"><a href="#home">Go to Top 👆</a></button>
    </div>
</footer>
</body>
</html>
