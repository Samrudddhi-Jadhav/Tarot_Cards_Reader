<?php
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $Phone = $_POST['Phone'];

  if(empty($username) || empty($email) || empty($password) || empty($Phone)){
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "form"

    //connection creating
    $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname)
    if(mysqli_connect_error()){
        die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());-
    }else{
        $SELECT = "SELECT email from student where email = ? Limit 1";
        $INSERT = "INSERT Into student(username, email, password,  Phone)values(?, ?, ?, ?)";

        //prepare statement
        $stmt = $conn->prepare($SELECT);
        $stmt->bind_param("s", $email);
        $stmt-> execute();
        $stmt->bind_result($email);
        $stmt->store_result();
        $rnum = $stmt->num_rows;
    }
    if($rnum==0){
        $stmt->close();
        $stmt-> $conn->prepare($INSERT);
        $stmt->bind_param("sssi", $username, $email, $password, $Phone);
        $stmt->execute();
        echo "New record inserted succesfully";
    }else{
        echo("Someone already using this email");
    }
    $stmt->close();
    $conn->close();
  }else{
    echo "All fields are required";
    die();
  }
?>