<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$host = "localhost";
$username = ""; // Add your database username
$password = ""; // Add your database password
$dbname = "form";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form data
$username = $_POST['username'];
$email = $_POST['email']; // Corrected to get email
$password = $_POST['password'];
$phone = $_POST['phone'];

// Validate the form data
if (empty($username) || empty($email) || empty($password) || empty($phone)) {
    echo "All fields are required";
    die();
}

// Sanitize the form data
$username = $conn->real_escape_string($username);
$email = $conn->real_escape_string($email);
$password = $conn->real_escape_string($password);
$phone = $conn->real_escape_string($phone);

// Check if the email already exists
$sql = "SELECT email FROM student WHERE email = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    // Insert the data into the database
    $sql = "INSERT INTO student (username, email, password, phone) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $username, $email, $password, $phone);
    $stmt->execute();
    echo "New record inserted successfully";
} else {
    echo "Someone already using this email";
}

$stmt->close();
$conn->close();
?>
