function showEmailForm() {
    var emailForm = document.getElementById("emailForm");
    emailForm.style.display = "block";
  }
  
  function hideEmailForm() {
    var emailForm = document.getElementById("emailForm");
    emailForm.style.display = "none";
  }
  