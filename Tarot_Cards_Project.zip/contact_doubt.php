<?php
$email = $_POST['email'];
$question = $_POST['question'];

// Send email to your email address
mail('samruddhi02jadhav@gmail.com', $email, $question);

// Output a success message
echo 'Thank you for your question! We will get back to you soon.';
