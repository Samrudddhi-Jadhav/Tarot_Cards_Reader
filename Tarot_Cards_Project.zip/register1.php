<?php
// Connect to the database
$servername = "localhost";
$username = ""; // Add your database username
$password = ""; // Add your database password
$dbname = "form";
$conn = mysqli_connect("$servername", "$username", "$password", "$dbname");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get the form data
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];

// Validate the form data
if (empty($username) || empty($email) || empty($password) || empty($phone)) {
  echo "All fields are required";
  exit;
}

// Hash the password
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Insert the data into the database
$sql = "INSERT INTO users (username, email, password, phone) VALUES ('$username', '$email', '$password_hash', '$phone')";
if (mysqli_query($conn, $sql)) {
  echo "New record inserted successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close the connection
mysqli_close($conn);
?>
