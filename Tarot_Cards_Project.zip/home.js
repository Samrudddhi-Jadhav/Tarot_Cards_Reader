// Add active class to current nav item
const navItems = document.querySelectorAll('header nav ul li');
const currentUrl = window.location.href;
const currentNavItem = navItems.find(item => item.href === currentUrl);
currentNavItem.classList.add('active');

// Search functionality
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const searchResults = document.getElementById('searchResults');

searchButton.addEventListener('click', () => {
    const searchQuery = searchInput.value.trim();
    const searchResultsHtml = '';
    const taritCards = [
        {
            name: 'The Fool',
            description: 'The Fool is the first card in the Major Arcana of a tarot deck. It is often associated with new beginnings, innocence, and spontaneity.'
        },
        {
            name: 'The Magician',
            description: 'The Magician is the second card in the Major Arcana of a tarot deck. It is often associated with skill, knowledge, and self-confidence.'
        },
        {
            name: 'The High Priestess',
            description: 'The High Priestess is the third card in the Major Arcana of a tarot deck. It is often associated with intuition, wisdom, and inner knowing.'
        },
        // Add more tarit cards here
    ];

    if (searchQuery.length === 0) {
        searchResultsHtml = '<p>No search results found.</p>';
    } else {
        const searchResultsArray = taritCards.filter(card => card.name.includes(searchQuery) || card.description.includes(searchQuery));
        searchResultsHtml = searchResultsArray.map(card => `<div>${card.name} - ${card.description}</div>`).join('');
    }

    searchResults.innerHTML = searchResultsHtml;
});
