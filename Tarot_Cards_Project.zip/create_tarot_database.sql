
CREATE DATABASE tarot_course;
USE tarot_course;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    paid BOOLEAN NOT NULL DEFAULT 0
);
