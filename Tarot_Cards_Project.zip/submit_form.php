<?php
// Connect to the database
$connection = mysqli_connect("localhost", "username", "password", "tarot_course");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    // Validate and sanitize input
    // Add more validations as needed
    $name = mysqli_real_escape_string($connection, $name);
    $email = mysqli_real_escape_string($connection, $email);
    $address = mysqli_real_escape_string($connection, $address);
    $phone = mysqli_real_escape_string($connection, $phone);

    // Save student details to the database
    $query = "INSERT INTO students (name, email, address, phone) VALUES ('$name', '$email', '$address', '$phone')";
    mysqli_query($connection, $query);

    // Redirect to payment gateway or WhatsApp group join
    // You can use a payment gateway API or other integration to process payments

    // Update student payment status
    $update_query = "UPDATE students SET paid=1 WHERE email='$email'";
    mysqli_query($connection, $update_query);

    // Redirect to WhatsApp group join link
    // header("Location: join_whatsapp_group.php");
}
?>
