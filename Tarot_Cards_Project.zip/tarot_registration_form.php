<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tarot Registration Form</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f3f3f3;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        max-width: 400px;
        width: 100%;
    }
    input[type="text"],
    input[type="email"],
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #007bff; /* Blue color for the button */
        color: #fff;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #0056b3; /* Darker shade of blue on hover */
    }
</style>
</head>
<body>
<form action="process_form.php" method="post">
    <input type="text" name="name" placeholder="Enter your name" required><br>
    <input type="email" name="email" placeholder="Enter your email" required><br>
    <input type="text" name="address" placeholder="Enter your address" required><br>
    <input type="text" name="phone" placeholder="Enter your phone number" required><br>
    <input type="submit" value="Pay 99 Rupees">
</form>
</body>
</html>
